package edu.cs3500.spreadsheets.model;

public interface Value extends Formula, CellContent {
  String toString();
}
