package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;

public interface Function extends Formula {


}