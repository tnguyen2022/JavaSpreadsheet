package edu.cs3500.spreadsheets.model;

/**
 * Representation of a formula.
 */
public interface Formula extends CellContent {
}
